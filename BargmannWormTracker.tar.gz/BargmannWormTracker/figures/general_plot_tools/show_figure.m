function show_figure(fignum)

gcf = figure(fignum);
set(gcf,'visible','on');

return;
end
