function grepstar(tag)
% function grepstar(tag)

grep('-r',tag,'*.m')

end
