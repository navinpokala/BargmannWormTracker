function getkeytest

tic;

if(getkey~=0)
    dummystring = sscanf('%s');

end;


toc;


end

